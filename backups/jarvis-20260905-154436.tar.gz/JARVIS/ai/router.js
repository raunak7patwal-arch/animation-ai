const animation = require("../../JARVIS/animation/orchestrator");

async function generateVideo(prompt, options={}) {
  if (!prompt || !String(prompt).trim()) {
    throw new Error("Prompt required");
  }

  return animation.generate(
    String(prompt),
    options
  );
}

async function generateImage(prompt, options={}) {
  const visual = require("../../visual-engine");

  const files = await visual.generateSceneVisuals({
    scenes: [{
      number: 1,
      visualPrompt: String(prompt)
    }],
    outputDir: options.outputDir ||
      "JARVIS/animation/output"
  });

  return {
    success: true,
    type: "image",
    file: files[0]
  };
}

async function generateVoice(text, options={}) {
  const voice = require("../../voice-engine");

  const file = await voice.generateVoice(
    String(text),
    options.outputFile ||
      "JARVIS/animation/audio/jarvis-voice.wav",
    options
  );

  return {
    success: true,
    type: "voice",
    file
  };
}

async function generate(type, input, options={}) {
  switch(String(type).toLowerCase()) {
    case "video":
    case "text-to-video":
    case "story":
      return generateVideo(input, options);

    case "image":
    case "text-to-image":
      return generateImage(input, options);

    case "voice":
    case "tts":
      return generateVoice(input, options);

    default:
      throw new Error(
        "Unsupported generation type: " + type
      );
  }
}

module.exports = {
  generate,
  generateVideo,
  generateImage,
  generateVoice
};
