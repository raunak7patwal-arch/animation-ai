const express = require("express");
const cors = require("cors");
const path = require("path");

const ai = require("../ai/router");

const app = express();

app.use(cors());
app.use(express.json({limit:"50mb"}));
app.use(express.urlencoded({
  extended:true,
  limit:"50mb"
}));

app.get("/api/jarvis/health",(req,res)=>{
  res.json({
    success:true,
    name:"JARVIS",
    status:"online",
    freeMode:true,
    localPipeline:true,
    engines:{
      story:true,
      animation:true,
      image:true,
      voice:true,
      audio:true,
      ffmpeg:true
    }
  });
});

app.post("/api/jarvis/generate",async(req,res)=>{
  try{
    const {
      type="video",
      prompt="",
      options={}
    }=req.body||{};

    const result=await ai.generate(
      type,
      prompt,
      options
    );

    res.json(result);

  }catch(error){
    console.error(error);

    res.status(500).json({
      success:false,
      error:error.message
    });
  }
});

app.post("/api/jarvis/video",async(req,res)=>{
  try{
    const result=
      await ai.generateVideo(
        req.body?.prompt,
        req.body?.options||{}
      );

    res.json(result);

  }catch(error){
    res.status(500).json({
      success:false,
      error:error.message
    });
  }
});

app.post("/api/jarvis/image",async(req,res)=>{
  try{
    const result=
      await ai.generateImage(
        req.body?.prompt,
        req.body?.options||{}
      );

    res.json(result);

  }catch(error){
    res.status(500).json({
      success:false,
      error:error.message
    });
  }
});

app.post("/api/jarvis/voice",async(req,res)=>{
  try{
    const result=
      await ai.generateVoice(
        req.body?.text,
        req.body?.options||{}
      );

    res.json(result);

  }catch(error){
    res.status(500).json({
      success:false,
      error:error.message
    });
  }
});

app.get("/api/jarvis/info",(req,res)=>{
  res.json({
    success:true,
    app:"JARVIS",
    version:"1.0.0",
    mode:"FREE_LOCAL",
    paidProvider:false,
    capabilities:[
      "story",
      "animation",
      "image",
      "voice",
      "music",
      "sfx",
      "video-editing",
      "mp4-render"
    ]
  });
});

module.exports=app;
